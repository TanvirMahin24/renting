# package-backend
1. Clone the repo
2. NPM install dependencies
3. Download XAMPP
4. Make DB in mysql
5. Run the project
